import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String url = "jdbc:sqlite:PIZZA.db";
        Scanner input = new Scanner(System.in);
        Connection kapcsolat = null;
            
// BEJELENTKEZÉS & KAPCSOLÓDÁS -----------------------------------------------------------
        System.out.println("\n=== Bejelentkezés ===");
        boolean belepve = false;
        
        while(!belepve) {
            System.out.print("Felhasználónév: ");
            	String felhasznalo = input.nextLine();
            System.out.print("Jelszó: ");
            	String jelszo = input.nextLine();
            
            if (felhasznalo.equals("admin") && jelszo.equals("admin1")) {
                System.out.println("SIKERES BELÉPÉS: " + felhasznalo);
                
                try {
                    Class.forName("org.sqlite.JDBC");
                    System.out.println("Driver sikeresen betöltve!");
                    kapcsolat = DriverManager.getConnection(url);
                    if (kapcsolat != null) {System.out.println("Sikeres csatlakozás az adatbázishoz!");}
                    else {System.out.println("Hiba a csatlakozáskor!");}
                    belepve = true;
                } catch (Exception e) {System.out.println("PROBLÉMA LÉPETT FEL: " + e.getMessage());}
                
            } else {System.out.println("Rossz felhasználónév vagy jelszó!");}
        }
// ---------------------------------------------------------------------------------------

int menu = -1; 
        
        while (menu != 0) {
            System.out.println("\n=== FŐMENÜ ===");
            System.out.println("1 - Új Ügyfél");
            System.out.println("2 - Új Étel");
            System.out.println("3 - Új Rendelés (Tételekkel)");
            System.out.println("4 - Ügyfél módosítása");
            System.out.println("5 - Étel módosítása");
            System.out.println("6 - Ügyfél törlése");
            System.out.println("7 - Étel törlése");
            System.out.println("8 - Rendelés törlése (Tételekkel)");
            System.out.println("9 - Ételek szűrése");
            System.out.println("10 - Ügyfelek szűrése");
            System.out.println("0 - Kilépés\n");
            
            try { menu = Integer.parseInt(input.nextLine()); }
            catch (Exception e) { menu = -1; continue; }
            
            try {

                // ÚJ ÜGYFÉL
                if (menu == 1) { 
                    System.out.print("(Név;Cím;Mobil;Szállítás)");
                    String[] a = input.nextLine().split(";");
                    PreparedStatement ps = kapcsolat.prepareStatement("INSERT INTO UGYFEL (nev, cim, mobil, szallitas) VALUES (?, ?, ?, ?)");
                    ps.setString(1, a[0]); ps.setString(2, a[1]); ps.setString(3, a[2]); ps.setString(4, a[3]);
                    ps.executeUpdate();
                    System.out.println("Rögzitve!");
                }

                // ÚJ ÉTEL
                else if (menu == 2) {
                    System.out.print("(Név;Ár;Elkészítés)");
                    String[] a = input.nextLine().split(";");
                    PreparedStatement ps = kapcsolat.prepareStatement("INSERT INTO ETLAP (nev, ar, elkeszites) VALUES (?, ?, ?)");
                    ps.setString(1, a[0]); ps.setString(2, a[1]); ps.setString(3, a[2]);
                    ps.executeUpdate();
                    System.out.println("Rögzitve!");
                }
                
                // ÚJ RENDELÉS
                else if (menu == 3) { 
                    System.out.print("Ügyfél ID: ");
                    String ugyfelid = input.nextLine();
                    
                    kapcsolat.createStatement().executeUpdate("INSERT INTO RENDELES (ugyfel_id) VALUES (" + ugyfelid + ")");
                    ResultSet rs = kapcsolat.createStatement().executeQuery("SELECT MAX(id) FROM RENDELES");
                    rs.next();
                    int last = rs.getInt(1);

                    while (true) {
                        System.out.print("(Étel ID;Mennyiség) vagy (0 a kilépéshez): ");
                        String[] a = input.nextLine().split(";");
                        if (a[0].equals("0")) {break;}
                        PreparedStatement ps = kapcsolat.prepareStatement("INSERT INTO TETELEK (rendeles_id, etel_id, mennyiseg) VALUES (?, ?, ?)");
                        ps.setInt(1, last); ps.setString(2, a[0]); ps.setString(3, a[1]);
                        ps.executeUpdate();
                    }
                    System.out.println("Rögzitve!");
                }
                
                // ÜGYFÉL MÓDOSÍTÁS
                else if (menu == 4) { 
                    System.out.print("Ügyfél ID: "); String id = input.nextLine();
                    System.out.print("(Név;Cím;Mobil;Szállítás): ");
                    String[] a = input.nextLine().split(";");
                    PreparedStatement ps = kapcsolat.prepareStatement("UPDATE UGYFEL SET nev=?, cim=?, mobil=?, szallitas=? WHERE id=?");
                    ps.setString(1, a[0]); ps.setString(2, a[1]); ps.setString(3, a[2]); ps.setString(4, a[3]); ps.setString(5, id);
                    ps.executeUpdate();
                    System.out.println("Módositva!");
                }

                // ÉTEL MÓDOSÍTÁS
                else if (menu == 5) { 
                    System.out.print("Étel ID: "); String id = input.nextLine();
                    System.out.print("(Név;Ár;Elkészítés): ");
                    String[] a = input.nextLine().split(";");
                    PreparedStatement ps = kapcsolat.prepareStatement("UPDATE ETLAP SET nev=?, ar=?, elkeszites=? WHERE id=?");
                    ps.setString(1, a[0]); ps.setString(2, a[1]); ps.setString(3, a[2]); ps.setString(4, id);
                    ps.executeUpdate();
                    System.out.println("Módositva!");
                }

                //ÜGYFÉL TÖRLÉS
                else if (menu == 6) { 
                    System.out.print("Ügyfél ID: ");
                    kapcsolat.createStatement().executeUpdate("DELETE FROM UGYFEL WHERE id = " + input.nextLine());
                    System.out.println("Törölve!");
                }
 
                // ÉTEL TÖRLÉS
                else if (menu == 7) { 
                    System.out.print("Étel ID: ");
                    kapcsolat.createStatement().executeUpdate("DELETE FROM ETLAP WHERE id = " + input.nextLine());
                    System.out.println("Törölve!");
                }
 
                // RENDELÉS TÖRLÉS
                else if (menu == 8) { 
                    System.out.print("Rendelés ID: ");
                    String id = input.nextLine();
                    kapcsolat.createStatement().executeUpdate("DELETE FROM TETELEK WHERE rendeles_id = " + id);
                    kapcsolat.createStatement().executeUpdate("DELETE FROM RENDELES WHERE id = " + id);
                    System.out.println("Törölve!");
                }
                
             // LEKÉRDEZÉS
                else if (menu == 9) {
                    System.out.print("Ételek legnagyobb ára (Ft): ");
                    String maxAr = input.nextLine();
                    ResultSet rs = kapcsolat.createStatement().executeQuery("SELECT * FROM ETLAP WHERE ar <= " + maxAr);
                    while (rs.next()) {System.out.println("- " + rs.getString("nev") + " (" + rs.getInt("ar") + " Ft)");}
                }

                // LEKÉRDEZÉS
                else if (menu == 10) {
                    System.out.print("Ügyfélnév része: ");
                    String nev = input.nextLine();
                    System.out.print("Ügyfélcím része: ");
                    String cim = input.nextLine();
                    
                    PreparedStatement ps = kapcsolat.prepareStatement("SELECT * FROM UGYFEL WHERE nev LIKE ? AND cim LIKE ?");
                    ps.setString(1, "%" + nev + "%");
                    ps.setString(2, "%" + cim + "%");
                    
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {System.out.println("- " + rs.getString("nev") + " | " + rs.getString("cim"));}
                }

                

                else if (menu == 0) { System.out.println("Kilépés..."); }

            } catch (Exception e) {System.out.println("Hiba történt: " + e.getMessage());}
        }
        input.close(); 
    } 
}